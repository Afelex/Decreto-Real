DECRETO REAL G3 — 9 IMÁGENES MAESTRAS Y 10 DERIVADOS WEBP

Maestros originales: maestros_png/
Derivados optimizados: public/interfaz/g3/
Copiar el directorio public/interfaz/g3 al repositorio sin reemplazar otros recursos.
El archivo manifest.json incluye dimensiones, alfa y SHA-256.
La pareja de puertas proviene de dividir el maestro.
Los botones se han adaptado mediante cortes para evitar deformar ornamentos.

La publicación debe probarse en móvil antes de considerar finalizada la integración.
